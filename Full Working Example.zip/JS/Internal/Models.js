Namespace.CRUD.ItemModel = Backbone.Model.extend();

Namespace.CRUD.ItemCollection = Backbone.Collection.extend({
	model: Namespace.CRUD.ItemModel 
});