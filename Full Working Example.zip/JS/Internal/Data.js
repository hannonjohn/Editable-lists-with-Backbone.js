Namespace.CRUD.Data = [
	{ id: 1, Title: "Cannery Row", Author: "John Steinbeck" },
	{ id: 2, Title: "The Old Man and the Sea", Author: "Ernest Hemmingway" },
	{ id: 3, Title: "The Catcher in the Rye", Author: "J.D. Salinger" },
	{ id: 4, Title: "Ask the Dust", Author: "John Fante" },
	{ id: 5, Title: "Hunger", Author: "Knut Hamsun" }
]